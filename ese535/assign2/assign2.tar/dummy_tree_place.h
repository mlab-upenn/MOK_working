/* main for use for assign 2 */
void dummy_tree_place(int size, int cluster_size);

/* exists primarily for debugging more general tree build for later assignments */
void dummy_tree_place_schedule(int *growth_schedule, int growth_schedule_length, int cluster_size);
