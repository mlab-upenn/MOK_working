void output_clustering (int **cluster_contents, int *cluster_occupancy, 
     int cluster_size, int inputs_per_cluster, int clocks_per_cluster, 
     int num_clusters, int lut_size, boolean global_clocks, boolean
     muxes_to_cluster_output_pins, boolean *is_clock, char *out_fname);
