/* count number of precedence violations according to assigned timestep */
int check_precedence(boolean report_violations);


