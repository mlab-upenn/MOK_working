void pack_luts_and_ffs (int lut_size);
void compress_netlist (int lut_size);
boolean *alloc_and_load_is_clock (boolean global_clocks, int lut_size); 
